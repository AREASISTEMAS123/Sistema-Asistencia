<?php

require __DIR__ . '/admin.php';
require __DIR__ . '/public.php';




